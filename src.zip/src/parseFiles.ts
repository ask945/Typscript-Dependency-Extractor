import { Project } from 'ts-morph';
import { FileAnalysis, ComponentInfo, FunctionInfo, InterfaceInfo, TypeInfo, ClassInfo, VariableInfo } from './utils/tokens';
import extractComponentInfo from './ComponentInfo';
import extractFunctionInfo from './FunctionInfo';
import extractInterfaceInfo from './InterfaceInfo';
import extractTypeInfo from './TypeInfo';
import extractClassInfo from './ClassInfo';
import extractVariableInfo from './VariableInfo';
import extractImportInfo from './ImportInfo';
import * as path from 'path';

export default function parseFiles(files: string[]): FileAnalysis[] {
    const project = new Project();
    const sourceFiles = files.map(file => project.addSourceFileAtPath(file));
    const fileAnalyses: FileAnalysis[] = [];
    
    
    sourceFiles.forEach(sourceFile => {
        const filePath = sourceFile.getFilePath();
        const fileName = path.basename(filePath);
        
       
        const components: ComponentInfo[] = [];
        
  
        sourceFile.getFunctions().forEach(func => {
            const isComponent = func.getName()?.charAt(0)?.toUpperCase() === func.getName()?.charAt(0);
            if (isComponent) {
                components.push(extractComponentInfo(func, "function"));
            }
        });

        sourceFile.getVariableDeclarations().forEach(varDecl => {
            const initializer = varDecl.getInitializer();
            const name = varDecl.getName();
            if (initializer && name.charAt(0).toUpperCase() === name.charAt(0)) {
                if (initializer.getKind() === 206) { // ArrowFunction kind
                    components.push(extractComponentInfo(varDecl, "arrow"));
                }
            }
        });
        
        // Extract standard classes (non-components)
        const classes: ClassInfo[] = [];
        sourceFile.getClasses().forEach(classDecl => {
            const isComponent = classDecl.getExtends()?.getText().includes('Component') || false;
            if (isComponent) {
                components.push(extractComponentInfo(classDecl, "class"));
            } else {
                classes.push(extractClassInfo(classDecl));
            }
        });

        const functions: FunctionInfo[] = [];
        sourceFile.getFunctions()
            .filter(func => !components.some(comp => comp.name === func.getName()))
            .forEach(func => {
                functions.push(extractFunctionInfo(func, "function"));
            });

        sourceFile.getVariableDeclarations().forEach(varDecl => {
            const initializer = varDecl.getInitializer();
            if (initializer && initializer.getKind() === 206 && // ArrowFunction kind
                !components.some(comp => comp.name === varDecl.getName())) {
                functions.push(extractFunctionInfo(varDecl, "arrow"));
            }
        });
        const interfaces: InterfaceInfo[] = sourceFile.getInterfaces().map(interfaceDecl => 
            extractInterfaceInfo(interfaceDecl)
        );

        const types: TypeInfo[] = sourceFile.getTypeAliases().map(typeAlias => 
            extractTypeInfo(typeAlias)
        );
        
        const variables: VariableInfo[] = [];
        sourceFile.getVariableStatements().forEach(statement => {
            statement.getDeclarations().forEach(declaration => {
                const initializer = declaration.getInitializer();
                if (!initializer || initializer.getKind() !== 206) { // Not an arrow function
                    variables.push(extractVariableInfo(declaration, statement));
                }
            });
        });
        
        const imports = sourceFile.getImportDeclarations().map(importDecl => 
            extractImportInfo(importDecl, filePath)
        );
        fileAnalyses.push({
            fileName,
            filePath,
            exports: {
                components,
                functions,
                interfaces,
                types,
                classes,
                variables
            },
            imports,
            incomingDependencies: [],
            outgoingDependencies: [],
            usedByComponents: []
        });
    });
    fileAnalyses.forEach(fileAnalysis => {
        fileAnalysis.incomingDependencies = fileAnalysis.imports
            .filter(imp => imp.resolvedFilePath)
            .map(imp => imp.resolvedFilePath as string);
    
        fileAnalyses.forEach(otherFile => {
            if (otherFile.filePath !== fileAnalysis.filePath) {
                const imports = otherFile.imports.filter(imp => 
                    imp.resolvedFilePath === fileAnalysis.filePath
                );
                
                if (imports.length > 0) {
                    fileAnalysis.outgoingDependencies.push(otherFile.filePath);
                }
            }
        });
        const componentUsage = new Set<string>();
        
        fileAnalyses.forEach(otherFile => {
            if (otherFile.filePath !== fileAnalysis.filePath) {
                const exportedNames = [
                    ...fileAnalysis.exports.components.filter(c => c.isExported).map(c => c.name),
                    ...fileAnalysis.exports.functions.filter(f => f.isExported).map(f => f.name),
                    ...fileAnalysis.exports.interfaces.filter(i => i.isExported).map(i => i.name),
                    ...fileAnalysis.exports.types.filter(t => t.isExported).map(t => t.name),
                    ...fileAnalysis.exports.classes.filter(c => c.isExported).map(c => c.name),
                    ...fileAnalysis.exports.variables.filter(v => v.isExported).map(v => v.name)
                ];

                otherFile.exports.components.forEach(component => {
                    // Check imports
                    const usesExport = otherFile.imports.some(imp => 
                        imp.resolvedFilePath === fileAnalysis.filePath && 
                        (imp.defaultImport || imp.namedImports.some(name => 
                            exportedNames.includes(name)
                        ))
                    );
                    
                    if (usesExport) {
                        componentUsage.add(component.name);
                    }
                });
            }
        });
        
        fileAnalysis.usedByComponents = Array.from(componentUsage);
    });
    
    return fileAnalyses;
}